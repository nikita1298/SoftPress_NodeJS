const mongoose=require('mongoose');

const articleSchema=mongoose.Schema({
    _id:mongoose.Types.ObjectId,
    article_type:{type:String,required:true},
    article:{
        article_id:mongoose.Types.ObjectId,
        user_id:{type:String,require:true,ref:'User'},
        author_id:{type:String,require:true,ref:'Author'},
        article_file:{type:String,require:true},
        description:{type:String,require:true},
        status:{type:String,required:true,default:'0'},
        created_date:{type:Date,default:Date.now()}  
    },
    created_date:{type:Date,default:Date.now()}
});
module.exports=mongoose.model('Article',articleSchema);